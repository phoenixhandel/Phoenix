import { afterEach, describe, expect, it, vi } from "vitest";

const invoke = vi.hoisted(() => vi.fn());
const getAuthClient = vi.hoisted(() => vi.fn(() => ({ functions: { invoke } })));

vi.mock("./auth-client", () => ({ getAuthClient }));

afterEach(() => {
  vi.clearAllMocks();
  vi.resetModules();
});

describe("withdrawal request helpers", () => {
  it("normalizes and validates an IBAN checksum", async () => {
    const { isValidIban, normalizeIban } = await import("./withdrawal-request");

    expect(normalizeIban("de89 3704 0044 0532 0130 00")).toBe(
      "DE89370400440532013000"
    );
    expect(isValidIban("DE89 3704 0044 0532 0130 00")).toBe(true);
    expect(isValidIban("DE89 3704 0044 0532 0130 01")).toBe(false);
  });

  it("submits the request through the authenticated Supabase function", async () => {
    invoke.mockResolvedValue({
      data: { ok: true, requestId: "wd_123" },
      error: null
    });
    const { submitWithdrawalRequest } = await import("./withdrawal-request");

    await expect(
      submitWithdrawalRequest({
        asset: "BTC",
        amount: 0.25,
        firstName: "Maria",
        lastName: "Muster",
        email: "member@example.test",
        iban: "DE89370400440532013000",
        agentCode: "123456",
        language: "de"
      })
    ).resolves.toEqual({ ok: true, requestId: "wd_123" });

    expect(invoke).toHaveBeenCalledWith("withdrawal-request", {
      body: {
        asset: "BTC",
        amount: 0.25,
        firstName: "Maria",
        lastName: "Muster",
        email: "member@example.test",
        iban: "DE89370400440532013000",
        agentCode: "123456",
        language: "de"
      }
    });
  });
});
