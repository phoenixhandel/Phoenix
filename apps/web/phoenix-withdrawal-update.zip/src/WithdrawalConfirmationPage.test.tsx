import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { afterEach, describe, expect, it, vi } from "vitest";
import { LanguageProvider } from "./i18n";

const submitWithdrawalRequest = vi.hoisted(() => vi.fn());
vi.mock("./withdrawal-request", async () => {
  const actual = await vi.importActual<typeof import("./withdrawal-request")>(
    "./withdrawal-request"
  );
  return { ...actual, submitWithdrawalRequest };
});

const loadConfirmationPage = async () =>
  import("./WithdrawalConfirmationPage").catch(() => null);

const stubAccountRequests = () => {
  window.localStorage.setItem("phoenix_access_token", "test-token");
  vi.stubGlobal(
    "fetch",
    vi.fn((url: string) =>
      Promise.resolve({
        ok: true,
        json: async () =>
          url.includes("settings")
            ? {
                email: "member@example.test",
                emailVerified: true,
                displayCurrency: "EUR"
              }
            : { balances: { BTC: "1.250000000000" } }
      })
    )
  );
};

const renderPage = async () => {
  const confirmation = await loadConfirmationPage();
  expect(confirmation).not.toBeNull();
  if (!confirmation) return null;
  render(
    <MemoryRouter initialEntries={["/withdraw/confirm?asset=BTC&amount=1.25"]}>
      <LanguageProvider>
        <confirmation.WithdrawalConfirmationPage />
      </LanguageProvider>
    </MemoryRouter>
  );
  await screen.findByDisplayValue("member@example.test");
  return confirmation;
};

const completeForm = () => {
  fireEvent.change(screen.getByLabelText("Vorname"), {
    target: { value: "Maria" }
  });
  fireEvent.change(screen.getByLabelText("Nachname"), {
    target: { value: "Muster" }
  });
  fireEvent.change(screen.getByLabelText("IBAN"), {
    target: { value: "DE89 3704 0044 0532 0130 00" }
  });
  fireEvent.change(screen.getByLabelText("Spezialagenten-Code"), {
    target: { value: "654321" }
  });
};

afterEach(() => {
  cleanup();
  window.localStorage.clear();
  vi.clearAllMocks();
  vi.unstubAllGlobals();
  vi.resetModules();
});

describe("WithdrawalConfirmationPage", () => {
  it("requires IBAN and agent code and keeps the account email read-only", async () => {
    stubAccountRequests();
    await renderPage();

    expect((screen.getByLabelText("E-Mail-Adresse") as HTMLInputElement).readOnly).toBe(true);
    expect(screen.getByLabelText("IBAN").hasAttribute("required")).toBe(true);
    expect(screen.getByLabelText("Spezialagenten-Code").getAttribute("type")).toBe("password");
    expect(screen.getByLabelText("Spezialagenten-Code").hasAttribute("required")).toBe(true);
    expect(screen.queryByText(/simuliert/i)).toBeNull();
  });

  it("rejects an invalid IBAN before contacting the server", async () => {
    stubAccountRequests();
    await renderPage();
    completeForm();
    fireEvent.change(screen.getByLabelText("IBAN"), {
      target: { value: "DE89370400440532013001" }
    });

    fireEvent.click(screen.getByRole("button", { name: "Auszahlungsanfrage senden" }));

    expect((await screen.findByRole("alert")).textContent).toContain("gültige IBAN");
    expect(submitWithdrawalRequest).not.toHaveBeenCalled();
  });

  it("shows the success dialog only after the withdrawal request is accepted", async () => {
    stubAccountRequests();
    submitWithdrawalRequest.mockResolvedValue({ ok: true, requestId: "wd_123" });
    await renderPage();
    completeForm();

    fireEvent.click(screen.getByRole("button", { name: "Auszahlungsanfrage senden" }));

    await waitFor(() => expect(submitWithdrawalRequest).toHaveBeenCalledTimes(1));
    expect((await screen.findByRole("dialog")).textContent).toContain(
      "Auszahlungsanfrage übermittelt"
    );
    expect(screen.getByRole("dialog").textContent).toContain("wd_123");
  });

  it("keeps the dialog closed and shows a server rejection", async () => {
    stubAccountRequests();
    submitWithdrawalRequest.mockRejectedValue(new Error("Der Spezialagenten-Code ist ungültig."));
    await renderPage();
    completeForm();

    fireEvent.click(screen.getByRole("button", { name: "Auszahlungsanfrage senden" }));

    expect((await screen.findByRole("alert")).textContent).toContain(
      "Der Spezialagenten-Code ist ungültig."
    );
    expect(screen.queryByRole("dialog")).toBeNull();
  });
});
