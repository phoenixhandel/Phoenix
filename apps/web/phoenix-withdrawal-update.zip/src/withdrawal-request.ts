import { getAuthClient } from "./auth-client";

export type WithdrawalRequestInput = {
  asset: string;
  amount: number;
  firstName: string;
  lastName: string;
  email: string;
  iban: string;
  agentCode: string;
  language: "de" | "en";
};

export type WithdrawalRequestResult = {
  ok: true;
  requestId: string;
};

type WithdrawalRequestFailure = {
  ok?: false;
  code?: string;
  message?: string;
};

export class WithdrawalRequestError extends Error {
  code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = "WithdrawalRequestError";
    this.code = code;
  }
}

export const normalizeIban = (value: string) =>
  value.replace(/\s+/g, "").toUpperCase();

export const isValidIban = (value: string) => {
  const iban = normalizeIban(value);
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban)) return false;

  const rearranged = `${iban.slice(4)}${iban.slice(0, 4)}`;
  let remainder = 0;

  for (const char of rearranged) {
    const numeric = /\d/.test(char) ? char : String(char.charCodeAt(0) - 55);
    for (const digit of numeric) {
      remainder = (remainder * 10 + Number(digit)) % 97;
    }
  }

  return remainder === 1;
};

const parseFunctionFailure = async (error: unknown) => {
  const fallback = new WithdrawalRequestError(
    "WITHDRAWAL_REQUEST_FAILED",
    "Withdrawal request could not be submitted."
  );

  if (!error || typeof error !== "object") return fallback;

  const errorRecord = error as {
    message?: unknown;
    context?: unknown;
  };
  const context = errorRecord.context;

  if (context && typeof context === "object" && "json" in context) {
    try {
      const payload = (await (context as Response).json()) as WithdrawalRequestFailure;
      if (payload?.message) {
        return new WithdrawalRequestError(
          payload.code ?? "WITHDRAWAL_REQUEST_FAILED",
          payload.message
        );
      }
    } catch {
      // Fall back to the SDK error message below.
    }
  }

  if (typeof errorRecord.message === "string" && errorRecord.message.trim()) {
    return new WithdrawalRequestError(
      "WITHDRAWAL_REQUEST_FAILED",
      errorRecord.message
    );
  }

  return fallback;
};

export const submitWithdrawalRequest = async (
  input: WithdrawalRequestInput
): Promise<WithdrawalRequestResult> => {
  const auth = getAuthClient();
  if (!auth) {
    throw new WithdrawalRequestError(
      "AUTH_UNAVAILABLE",
      "Authentication is not configured."
    );
  }

  const { data, error } = await auth.functions.invoke("withdrawal-request", {
    body: {
      ...input,
      asset: input.asset.toUpperCase(),
      firstName: input.firstName.trim(),
      lastName: input.lastName.trim(),
      email: input.email.trim(),
      iban: normalizeIban(input.iban),
      agentCode: input.agentCode.trim()
    }
  });

  if (error) throw await parseFunctionFailure(error);

  if (
    !data ||
    data.ok !== true ||
    typeof data.requestId !== "string" ||
    !data.requestId.trim()
  ) {
    const failure = data as WithdrawalRequestFailure | null;
    throw new WithdrawalRequestError(
      failure?.code ?? "WITHDRAWAL_REQUEST_FAILED",
      failure?.message ?? "Withdrawal request could not be submitted."
    );
  }

  return { ok: true, requestId: data.requestId };
};
