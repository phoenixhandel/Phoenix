export const percentageBaseAmount = (
  side: "BUY" | "SELL",
  availableBalance: number,
  marketPrice: number,
  percentage: number
) => {
  const fraction = percentage / 100;
  if (!Number.isFinite(availableBalance) || availableBalance <= 0 || fraction <= 0) {
    return 0;
  }
  if (side === "SELL") return availableBalance * fraction;
  if (!Number.isFinite(marketPrice) || marketPrice <= 0) return 0;
  return (availableBalance * fraction) / marketPrice;
};
