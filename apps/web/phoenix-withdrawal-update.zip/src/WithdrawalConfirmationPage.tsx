import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useAuthSession } from "./auth-session";
import { useLanguage } from "./i18n";
import { getPortfolioAssetPrices } from "./market-data";
import {
  isValidIban,
  normalizeIban,
  submitWithdrawalRequest,
  WithdrawalRequestError
} from "./withdrawal-request";
import { WorkspaceShell } from "./WorkspaceShell";

const apiBase = import.meta.env.VITE_API_BASE_URL ?? "";
const validAssets = new Set(["BTC", "ETH", "SOL", "XRP", "USDT"]);
const formatEuro = (value: number, language: "de" | "en") =>
  new Intl.NumberFormat(language === "de" ? "de-DE" : "en-IE", {
    style: "currency",
    currency: "EUR"
  }).format(value);

const copy = {
  de: {
    title: "Auszahlung bestätigen",
    description: "Prüfe die Auszahlungsdaten und sende deine Anfrage.",
    status: "AUSZAHLUNGSPRÜFUNG",
    firstName: "Vorname",
    lastName: "Nachname",
    email: "E-Mail-Adresse",
    emailHint: "Die Bestätigung wird an die E-Mail-Adresse deines Kontos gesendet.",
    iban: "IBAN",
    ibanPlaceholder: "DE89 3704 0044 0532 0130 00",
    agentCode: "Spezialagenten-Code",
    agentCodeHint: "Gib den dir mitgeteilten Verifizierungscode ein.",
    amount: "Angefragter Betrag",
    equivalent: "Geschätzter Gegenwert",
    confirm: "Auszahlungsanfrage senden",
    sending: "Anfrage wird gesendet…",
    invalid:
      "Diese Anfrage ist nicht mehr gültig. Bitte beginne erneut im Portfolio.",
    exceeds: "Der Betrag überschreitet deinen aktuellen Bestand.",
    invalidIban: "Gib eine gültige IBAN ein.",
    invalidAgentCode: "Der Spezialagenten-Code ist ungültig.",
    emailMismatch:
      "Die Konto-E-Mail konnte nicht bestätigt werden. Melde dich erneut an und versuche es noch einmal.",
    requestFailed:
      "Die Auszahlungsanfrage konnte nicht übermittelt werden. Bitte versuche es erneut.",
    confirmedTitle: "Auszahlungsanfrage übermittelt",
    confirmedCopy:
      "Deine Auszahlungsanfrage wurde angenommen und eine Bestätigung an deine Konto-E-Mail gesendet. Die weitere Bearbeitung erfolgt separat; diese Bestätigung ist noch kein Nachweis einer Bank- oder Blockchain-Abwicklung.",
    requestReference: "Anfragereferenz",
    close: "Schließen"
  },
  en: {
    title: "Confirm withdrawal request",
    description: "Review the withdrawal details and submit your request.",
    status: "WITHDRAWAL REVIEW",
    firstName: "First name",
    lastName: "Last name",
    email: "Email address",
    emailHint: "The confirmation is sent to the email address on your account.",
    iban: "IBAN",
    ibanPlaceholder: "DE89 3704 0044 0532 0130 00",
    agentCode: "Special agent code",
    agentCodeHint: "Enter the verification code provided to you.",
    amount: "Requested amount",
    equivalent: "Estimated EUR value",
    confirm: "Submit withdrawal request",
    sending: "Submitting request…",
    invalid:
      "This request is no longer valid. Please start again from your portfolio.",
    exceeds: "The amount exceeds your current balance.",
    invalidIban: "Enter a valid IBAN.",
    invalidAgentCode: "The special agent code is invalid.",
    emailMismatch:
      "Your account email could not be verified. Sign in again and retry.",
    requestFailed:
      "The withdrawal request could not be submitted. Please try again.",
    confirmedTitle: "Withdrawal request submitted",
    confirmedCopy:
      "Your withdrawal request was accepted and a confirmation was sent to your account email. Further processing happens separately; this confirmation is not yet proof of bank or blockchain settlement.",
    requestReference: "Request reference",
    close: "Close"
  }
} as const;

export const WithdrawalConfirmationPage = () => {
  const { language } = useLanguage();
  const { session } = useAuthSession();
  const [params] = useSearchParams();
  const text = copy[language];
  const asset = (params.get("asset") ?? "").toUpperCase();
  const amount = Number(params.get("amount"));
  const token = window.localStorage.getItem("phoenix_access_token");
  const metadata = session?.user.user_metadata ?? {};
  const fullName =
    typeof metadata.full_name === "string"
      ? metadata.full_name.trim().split(/\s+/, 2)
      : [];
  const [firstName, setFirstName] = useState(
    typeof metadata.first_name === "string"
      ? metadata.first_name
      : (fullName[0] ?? "")
  );
  const [lastName, setLastName] = useState(
    typeof metadata.last_name === "string"
      ? metadata.last_name
      : (fullName[1] ?? "")
  );
  const [email, setEmail] = useState(session?.user.email ?? "");
  const [iban, setIban] = useState("");
  const [agentCode, setAgentCode] = useState("");
  const [available, setAvailable] = useState<number | null>(null);
  const [price, setPrice] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [requestId, setRequestId] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const isRequestValid =
    validAssets.has(asset) && Number.isFinite(amount) && amount > 0;
  const canConfirm = Boolean(
    isRequestValid &&
      available !== null &&
      amount <= available &&
      firstName.trim() &&
      lastName.trim() &&
      email.trim() &&
      iban.trim() &&
      agentCode.trim() &&
      !submitting
  );

  useEffect(() => {
    if (!token || !isRequestValid) return;
    void Promise.all([
      fetch(`${apiBase}/api/me/portfolio`, {
        headers: { authorization: `Bearer ${token}` }
      }).then(async (response) => {
        if (!response.ok) throw new Error();
        return response.json() as Promise<{ balances: Record<string, string> }>;
      }),
      fetch(`${apiBase}/api/me/settings`, {
        headers: { authorization: `Bearer ${token}` }
      }).then(async (response) => {
        if (!response.ok) throw new Error();
        return response.json() as Promise<{ email: string | null }>;
      }),
      getPortfolioAssetPrices("EUR").catch((): Record<string, number> => ({}))
    ])
      .then(([portfolio, settings, prices]) => {
        setAvailable(Number(portfolio.balances[asset] ?? 0));
        setEmail(session?.user.email ?? settings.email ?? "");
        setPrice(prices[asset] ?? null);
      })
      .catch(() => setAvailable(0));
  }, [asset, isRequestValid, session?.user.email, token]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!canConfirm) return;

    if (!isValidIban(iban)) {
      setFormError(text.invalidIban);
      return;
    }

    setSubmitting(true);
    setFormError(null);

    try {
      const result = await submitWithdrawalRequest({
        asset,
        amount,
        firstName,
        lastName,
        email,
        iban: normalizeIban(iban),
        agentCode,
        language
      });
      setRequestId(result.requestId);
      setAgentCode("");
      setConfirmed(true);
    } catch (error) {
      if (error instanceof WithdrawalRequestError) {
        if (error.code === "INVALID_AGENT_CODE") {
          setFormError(text.invalidAgentCode);
        } else if (error.code === "EMAIL_MISMATCH") {
          setFormError(text.emailMismatch);
        } else if (error.code === "INSUFFICIENT_BALANCE") {
          setFormError(text.exceeds);
        } else {
          setFormError(error.message || text.requestFailed);
        }
      } else if (error instanceof Error && error.message) {
        setFormError(error.message);
      } else {
        setFormError(text.requestFailed);
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <WorkspaceShell
      active="account"
      title={text.title}
      description={text.description}
      meta={
        <span className="border border-cyan-300/30 bg-cyan-300/5 px-2 py-1 font-mono text-[10px] font-bold tracking-[0.12em] text-cyan-100">
          {text.status}
        </span>
      }
      actions={
        <a
          href="/withdraw"
          className="inline-flex min-h-10 items-center border border-[#2a3a54] px-3 text-sm font-semibold text-slate-200 transition hover:border-cyan-300 hover:text-white"
        >
          {language === "de" ? "Zurück" : "Back"}
        </a>
      }
    >
      <section className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(300px,.72fr)]">
        <form
          onSubmit={(event) => void submit(event)}
          className="border border-[#1e2a40] bg-[#0d1727] p-5"
        >
          {!isRequestValid ||
          available === 0 ||
          (available !== null && amount > available) ? (
            <p
              role="alert"
              className="border border-rose-300/40 bg-rose-300/5 px-4 py-3 text-sm text-rose-100"
            >
              {!isRequestValid ? text.invalid : text.exceeds}
            </p>
          ) : null}
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block text-sm text-slate-300">
              {text.firstName}
              <input
                aria-label={text.firstName}
                required
                value={firstName}
                onChange={(event) => setFirstName(event.target.value)}
                className="mt-2 w-full border border-[#2a3a54] bg-[#0a1322] px-3 py-3 text-white outline-none focus:border-cyan-300"
              />
            </label>
            <label className="block text-sm text-slate-300">
              {text.lastName}
              <input
                aria-label={text.lastName}
                required
                value={lastName}
                onChange={(event) => setLastName(event.target.value)}
                className="mt-2 w-full border border-[#2a3a54] bg-[#0a1322] px-3 py-3 text-white outline-none focus:border-cyan-300"
              />
            </label>
          </div>
          <label className="mt-4 block text-sm text-slate-300">
            {text.email}
            <input
              aria-label={text.email}
              required
              readOnly
              type="email"
              value={email}
              className="mt-2 w-full cursor-not-allowed border border-[#2a3a54] bg-[#091321] px-3 py-3 text-slate-300 outline-none"
            />
            <span className="mt-2 block text-xs leading-5 text-slate-500">
              {text.emailHint}
            </span>
          </label>
          <label className="mt-4 block text-sm text-slate-300">
            {text.iban}
            <input
              aria-label={text.iban}
              required
              autoComplete="off"
              spellCheck={false}
              value={iban}
              onChange={(event) => {
                setIban(event.target.value.toUpperCase());
                setFormError(null);
              }}
              placeholder={text.ibanPlaceholder}
              className="mt-2 w-full border border-[#2a3a54] bg-[#0a1322] px-3 py-3 font-mono text-white outline-none focus:border-cyan-300"
            />
          </label>
          <label className="mt-4 block text-sm text-slate-300">
            {text.agentCode}
            <input
              aria-label={text.agentCode}
              required
              type="password"
              inputMode="numeric"
              autoComplete="off"
              value={agentCode}
              onChange={(event) => {
                setAgentCode(event.target.value);
                setFormError(null);
              }}
              className="mt-2 w-full border border-[#2a3a54] bg-[#0a1322] px-3 py-3 font-mono tracking-[0.18em] text-white outline-none focus:border-cyan-300"
            />
            <span className="mt-2 block text-xs leading-5 text-slate-500">
              {text.agentCodeHint}
            </span>
          </label>
          {formError ? (
            <p
              role="alert"
              className="mt-5 border border-rose-300/40 bg-rose-300/5 px-4 py-3 text-sm text-rose-100"
            >
              {formError}
            </p>
          ) : null}
          <button
            disabled={!canConfirm}
            className="mt-6 min-h-11 bg-cyan-300 px-5 text-sm font-bold text-[#07101e] transition hover:bg-cyan-200 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {submitting ? text.sending : text.confirm}
          </button>
        </form>
        <aside className="border border-[#1e2a40] bg-[#0d1727] p-5">
          <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-500">
            {text.amount}
          </p>
          <p className="mt-5 font-mono text-3xl font-semibold tabular-nums text-white">
            {isRequestValid ? `${amount.toFixed(12)} ${asset}` : "—"}
          </p>
          <p className="mt-2 font-mono text-sm tabular-nums text-slate-400">
            {price ? formatEuro(amount * price, language) : "—"}
          </p>
          <div className="mt-7 border-t border-[#1e2a40] pt-5">
            <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-500">
              {text.equivalent}
            </p>
            <p className="mt-2 text-sm leading-6 text-slate-400">
              {language === "de"
                ? "Der Betrag wird vor dem Absenden erneut gegen deinen aktuellen Bestand geprüft."
                : "The amount is checked against your current balance again before submission."}
            </p>
          </div>
        </aside>
      </section>
      {confirmed ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="withdrawal-confirmed-title"
          className="fixed inset-0 z-50 grid place-items-center bg-[#030914]/75 p-5 backdrop-blur-sm"
        >
          <section className="w-full max-w-md border border-emerald-300/50 bg-[#0d1727] p-8 text-center">
            <div
              aria-hidden="true"
              className="mx-auto grid h-20 w-20 place-items-center rounded-full border-2 border-emerald-300 bg-emerald-300/10 text-5xl font-light text-emerald-200"
            >
              ✓
            </div>
            <h2
              id="withdrawal-confirmed-title"
              className="mt-6 text-2xl font-semibold text-white"
            >
              {text.confirmedTitle}
            </h2>
            <p className="mt-3 text-sm leading-6 text-slate-300">
              {text.confirmedCopy}
            </p>
            {requestId ? (
              <p className="mt-4 font-mono text-xs text-slate-500">
                {text.requestReference}: {requestId}
              </p>
            ) : null}
            <button
              type="button"
              onClick={() => setConfirmed(false)}
              className="mt-7 min-h-11 border border-[#2a3a54] px-5 text-sm font-semibold text-slate-200 transition hover:border-cyan-300 hover:text-white"
            >
              {text.close}
            </button>
          </section>
        </div>
      ) : null}
    </WorkspaceShell>
  );
};
