import { describe, expect, it } from "vitest";
import { percentageBaseAmount } from "./order-calculations";

describe("percentageBaseAmount", () => {
  it("converts quote balance into base amount for buy orders", () => {
    expect(percentageBaseAmount("BUY", 1000, 50000, 25)).toBeCloseTo(0.005);
  });

  it("uses the base balance directly for sell orders", () => {
    expect(percentageBaseAmount("SELL", 2, 50000, 25)).toBeCloseTo(0.5);
  });

  it("returns zero when a buy price is unavailable", () => {
    expect(percentageBaseAmount("BUY", 1000, 0, 25)).toBe(0);
  });
});
