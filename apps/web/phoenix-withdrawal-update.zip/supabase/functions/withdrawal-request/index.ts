import { withSupabase } from "npm:@supabase/server@^1";
import { escapeHtml, isValidIban, maskIban, normalizeIban } from "./logic.ts";

type WithdrawalRequestBody = {
  asset?: unknown;
  amount?: unknown;
  firstName?: unknown;
  lastName?: unknown;
  email?: unknown;
  iban?: unknown;
  agentCode?: unknown;
  language?: unknown;
};

const validAssets = new Set(["BTC", "ETH", "SOL", "XRP", "USDT"]);

const jsonError = (status: number, code: string, message: string) =>
  Response.json({ ok: false, code, message }, { status });

const readRequiredSecret = (name: string) => {
  const value = Deno.env.get(name)?.trim();
  return value || null;
};

const cleanText = (value: unknown, maxLength: number) =>
  typeof value === "string" ? value.trim().slice(0, maxLength) : "";

const emailCopy = (language: "de" | "en") =>
  language === "de"
    ? {
        subject: "Auszahlungsanfrage bestätigt",
        heading: "Auszahlungsanfrage bestätigt",
        intro:
          "Wir haben deine Auszahlungsanfrage erhalten und zur weiteren Bearbeitung vorgemerkt.",
        amount: "Betrag",
        iban: "IBAN",
        reference: "Anfragereferenz",
        note:
          "Diese E-Mail bestätigt den Eingang der Anfrage. Sie ist noch kein Nachweis einer abgeschlossenen Bank- oder Blockchain-Abwicklung."
      }
    : {
        subject: "Withdrawal request confirmed",
        heading: "Withdrawal request confirmed",
        intro:
          "We received your withdrawal request and recorded it for further processing.",
        amount: "Amount",
        iban: "IBAN",
        reference: "Request reference",
        note:
          "This email confirms receipt of the request. It is not yet proof of completed bank or blockchain settlement."
      };

const handler = async (request: Request, context: { userClaims?: Record<string, unknown> }) => {
  if (request.method !== "POST") {
    return jsonError(405, "METHOD_NOT_ALLOWED", "Method not allowed.");
  }

  let body: WithdrawalRequestBody;
  try {
    body = (await request.json()) as WithdrawalRequestBody;
  } catch {
    return jsonError(400, "INVALID_BODY", "Request body must be valid JSON.");
  }

  const asset = cleanText(body.asset, 10).toUpperCase();
  const amount = typeof body.amount === "number" ? body.amount : Number(body.amount);
  const firstName = cleanText(body.firstName, 100);
  const lastName = cleanText(body.lastName, 100);
  const submittedEmail = cleanText(body.email, 320).toLowerCase();
  const iban = normalizeIban(cleanText(body.iban, 64));
  const agentCode = cleanText(body.agentCode, 64);
  const language = body.language === "en" ? "en" : "de";

  if (!validAssets.has(asset) || !Number.isFinite(amount) || amount <= 0) {
    return jsonError(400, "INVALID_REQUEST", "Asset or amount is invalid.");
  }
  if (!firstName || !lastName || !submittedEmail || !iban || !agentCode) {
    return jsonError(400, "MISSING_FIELDS", "All withdrawal fields are required.");
  }
  if (!isValidIban(iban)) {
    return jsonError(400, "INVALID_IBAN", "The IBAN is invalid.");
  }

  const accountEmail =
    typeof context.userClaims?.email === "string"
      ? context.userClaims.email.trim().toLowerCase()
      : "";
  if (!accountEmail) {
    return jsonError(401, "ACCOUNT_EMAIL_MISSING", "Authenticated account email is unavailable.");
  }
  if (submittedEmail !== accountEmail) {
    return jsonError(409, "EMAIL_MISMATCH", "The submitted email does not match the authenticated account.");
  }

  const configuredAgentCode = readRequiredSecret("WITHDRAWAL_AGENT_CODE");
  const phoenixApiBase = readRequiredSecret("PHOENIX_API_BASE_URL");
  const resendApiKey = readRequiredSecret("RESEND_API_KEY");
  const fromEmail = readRequiredSecret("WITHDRAWAL_FROM_EMAIL");
  if (!configuredAgentCode || !phoenixApiBase || !resendApiKey || !fromEmail) {
    return jsonError(500, "CONFIGURATION_ERROR", "Withdrawal email service is not fully configured.");
  }
  if (agentCode !== configuredAgentCode) {
    return jsonError(403, "INVALID_AGENT_CODE", "The special agent code is invalid.");
  }

  const authorization = request.headers.get("authorization");
  if (!authorization) {
    return jsonError(401, "AUTHORIZATION_MISSING", "Authorization header is missing.");
  }

  let portfolioResponse: Response;
  try {
    portfolioResponse = await fetch(
      `${phoenixApiBase.replace(/\/$/, "")}/api/me/portfolio`,
      {
        headers: {
          authorization,
          accept: "application/json"
        }
      }
    );
  } catch {
    return jsonError(502, "PORTFOLIO_UNAVAILABLE", "Portfolio service is unavailable.");
  }

  if (!portfolioResponse.ok) {
    return jsonError(502, "PORTFOLIO_UNAVAILABLE", "Portfolio balance could not be verified.");
  }

  let balances: Record<string, string>;
  try {
    const payload = (await portfolioResponse.json()) as {
      balances?: Record<string, string>;
    };
    balances = payload.balances ?? {};
  } catch {
    return jsonError(502, "PORTFOLIO_UNAVAILABLE", "Portfolio response was invalid.");
  }

  const available = Number(balances[asset] ?? 0);
  if (!Number.isFinite(available) || amount > available) {
    return jsonError(409, "INSUFFICIENT_BALANCE", "The requested amount exceeds the current balance.");
  }

  const requestId = `wd_${crypto.randomUUID()}`;
  const copy = emailCopy(language);
  const safeName = escapeHtml(`${firstName} ${lastName}`.trim());
  const safeAsset = escapeHtml(asset);
  const safeAmount = escapeHtml(String(amount));
  const safeIban = escapeHtml(maskIban(iban));
  const safeRequestId = escapeHtml(requestId);

  let resendResponse: Response;
  try {
    resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendApiKey}`,
        "Idempotency-Key": `withdrawal-request/${requestId}`
      },
      body: JSON.stringify({
        from: fromEmail,
        to: [accountEmail],
        subject: `${copy.subject} · ${asset}`,
        html: `
          <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;color:#111827;line-height:1.6">
            <h1 style="font-size:24px;margin:0 0 20px">${escapeHtml(copy.heading)}</h1>
            <p>${escapeHtml(copy.intro)}</p>
            <p>${safeName}</p>
            <table style="width:100%;border-collapse:collapse;margin:24px 0">
              <tr><td style="padding:10px 0;border-bottom:1px solid #e5e7eb">${escapeHtml(copy.amount)}</td><td style="padding:10px 0;border-bottom:1px solid #e5e7eb;text-align:right"><strong>${safeAmount} ${safeAsset}</strong></td></tr>
              <tr><td style="padding:10px 0;border-bottom:1px solid #e5e7eb">${escapeHtml(copy.iban)}</td><td style="padding:10px 0;border-bottom:1px solid #e5e7eb;text-align:right"><strong>${safeIban}</strong></td></tr>
              <tr><td style="padding:10px 0">${escapeHtml(copy.reference)}</td><td style="padding:10px 0;text-align:right"><code>${safeRequestId}</code></td></tr>
            </table>
            <p style="font-size:13px;color:#6b7280">${escapeHtml(copy.note)}</p>
          </div>
        `
      })
    });
  } catch {
    return jsonError(502, "EMAIL_DELIVERY_FAILED", "Confirmation email could not be sent.");
  }

  if (!resendResponse.ok) {
    console.error("Resend rejected withdrawal confirmation email", {
      status: resendResponse.status,
      requestId
    });
    return jsonError(502, "EMAIL_DELIVERY_FAILED", "Confirmation email could not be sent.");
  }

  return Response.json({ ok: true, requestId });
};

export default {
  fetch: withSupabase({ auth: "user" }, handler)
};
