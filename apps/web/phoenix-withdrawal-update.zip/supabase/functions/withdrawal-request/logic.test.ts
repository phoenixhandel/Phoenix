import { isValidIban, maskIban, normalizeIban } from "./logic.ts";

const assertEquals = (actual: unknown, expected: unknown) => {
  if (actual !== expected) {
    throw new Error(`Expected ${String(expected)}, received ${String(actual)}`);
  }
};

Deno.test("normalizes and validates IBAN values", () => {
  assertEquals(
    normalizeIban("de89 3704 0044 0532 0130 00"),
    "DE89370400440532013000"
  );
  assertEquals(isValidIban("DE89 3704 0044 0532 0130 00"), true);
  assertEquals(isValidIban("DE89 3704 0044 0532 0130 01"), false);
});

Deno.test("masks all but the last four IBAN characters", () => {
  assertEquals(maskIban("DE89370400440532013000"), "DE•• •••• •••• •••• ••30 00");
});
