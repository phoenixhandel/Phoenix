export const normalizeIban = (value: string) =>
  value.replace(/\s+/g, "").toUpperCase();

export const isValidIban = (value: string) => {
  const iban = normalizeIban(value);
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban)) return false;

  const rearranged = `${iban.slice(4)}${iban.slice(0, 4)}`;
  let remainder = 0;

  for (const char of rearranged) {
    const numeric = /\d/.test(char) ? char : String(char.charCodeAt(0) - 55);
    for (const digit of numeric) {
      remainder = (remainder * 10 + Number(digit)) % 97;
    }
  }

  return remainder === 1;
};

export const maskIban = (value: string) => {
  const iban = normalizeIban(value);
  if (iban.length <= 8) return iban;
  const masked = `${iban.slice(0, 2)}${"•".repeat(iban.length - 6)}${iban.slice(-4)}`;
  return masked.match(/.{1,4}/g)?.join(" ") ?? masked;
};

export const escapeHtml = (value: string) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
