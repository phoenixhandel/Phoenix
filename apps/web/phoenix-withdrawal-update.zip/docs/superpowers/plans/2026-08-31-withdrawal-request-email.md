# Withdrawal Request Email Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Convert the frontend-only withdrawal confirmation into an authenticated request workflow with required IBAN/agent-code inputs and server-side Resend confirmation email.

**Architecture:** Keep portfolio display and first-pass validation in the existing React pages. Add a small frontend withdrawal-request helper and an authenticated Supabase Edge Function that re-checks balance through the Phoenix backend, validates the server-only agent code, and calls Resend.

**Tech Stack:** React, TypeScript, Supabase Auth/Edge Functions, Resend REST API, Vitest/Testing Library.

**Spec:** `docs/superpowers/specs/2026-08-31-withdrawal-request-email-design.md`

## Global Constraints
- Do not expose `RESEND_API_KEY` or `WITHDRAWAL_AGENT_CODE` in browser/Vite code.
- Email only the authenticated Supabase account email.
- Do not claim that bank/blockchain settlement is complete when the implementation only records/submits a request and sends email.
- Keep internal backend contract field `simulationPaused` unchanged.
- Preserve German and English UI copy.

---

### Task 1: Withdrawal request helper and validation

**Files:**
- Create: `src/withdrawal-request.ts`
- Create: `src/withdrawal-request.test.ts`

**Interfaces:**
- Produces: `normalizeIban(value: string): string`
- Produces: `isValidIban(value: string): boolean`
- Produces: `submitWithdrawalRequest(input: WithdrawalRequestInput): Promise<WithdrawalRequestResult>`

- [x] Write tests covering IBAN normalization/checksum and authenticated Supabase function invocation.
- [x] Run the focused test and confirm the new expectations fail before implementation.
- [x] Implement the minimal helper and invocation logic.
- [x] Run the focused test and confirm it passes.

### Task 2: Confirmation form behavior

**Files:**
- Modify: `src/WithdrawalConfirmationPage.tsx`
- Modify: `src/WithdrawalConfirmationPage.test.tsx`

**Interfaces:**
- Consumes: `isValidIban`, `normalizeIban`, `submitWithdrawalRequest` from `src/withdrawal-request.ts`.

- [x] Extend tests for required IBAN/agent code, readonly account email, invalid IBAN, server rejection, pending state, and successful dialog.
- [x] Run the focused test and confirm failures are caused by missing behavior.
- [x] Implement the new fields, validation, request submission, error/pending state, and success dialog.
- [x] Run the focused test and confirm it passes.

### Task 3: Withdrawal review and trust-consistent copy

**Files:**
- Modify: `src/WithdrawalReviewPage.tsx`
- Modify: `src/WithdrawalReviewPage.test.tsx`
- Modify: `src/InformationPage.tsx`
- Modify: `src/App.tsx`

**Interfaces:**
- No new runtime interfaces.

- [x] Add/adjust tests so customer-facing withdrawal pages do not render simulation/demo wording.
- [x] Update withdrawal meta copy to neutral review wording.
- [x] Remove contradictory claims that Phoenix cannot accept a withdrawal request while keeping accurate custody/settlement boundaries.
- [x] Verify no customer-facing simulation/demo wording remains in implementation files.

### Task 3B: Trading consistency fixes

**Files:**
- Create: `src/order-calculations.ts`
- Create: `src/order-calculations.test.ts`
- Modify: `src/App.tsx`
- Modify: `src/App.test.tsx`

- [x] Remove hard-coded fallback prices, order-book rows, and fabricated market-activity rows.
- [x] Replace fabricated market activity with live feed status/source information.
- [x] Correct BUY percentage sizing so quote balance is divided by current market price.
- [x] Disable unsupported limit/stop controls instead of making them look usable.
- [x] Remove static fee/execution estimates that can disagree with administrator market settings.

### Task 4: Supabase Edge Function + Resend

**Files:**
- Create: `supabase/functions/withdrawal-request/index.ts`
- Create: `supabase/config.toml`
- Create: `supabase/functions/.env.example`
- Create: `docs/RESEND_WITHDRAWAL_SETUP.md`

**Interfaces:**
- Consumes JSON `{ asset, amount, firstName, lastName, email, iban, agentCode }`.
- Returns JSON success `{ ok: true, requestId: string }`.
- Returns JSON error `{ ok: false, code: string, message: string }` with appropriate HTTP status.

- [x] Implement authenticated Edge Function validation and CORS handling.
- [x] Forward the caller's bearer token to `${PHOENIX_API_BASE_URL}/api/me/portfolio` and reject insufficient balances.
- [x] Validate `WITHDRAWAL_AGENT_CODE` server-side.
- [x] Send Resend email to authenticated user email with masked IBAN and request reference.
- [x] Document domain verification, secret setup, local testing, deployment, and smoke-test commands.

### Task 5: Verification and package

**Files:**
- All modified files.

- [x] Search implementation files for visible `simulated`, `simulation`, and `demo` copy and review every match.
- [x] Run available tests; if the archive lacks its package manifest/dependencies, record that limitation and run TypeScript syntax transpilation on all `.ts/.tsx` files.
- [x] Zip the updated source tree for handoff.


## Verification note

The supplied archive has no `package.json`, dependency lockfile, or installed project dependencies, so Vitest cannot be executed from this archive alone. All TS/TSX files were syntax-transpiled successfully and the pure IBAN/order-calculation logic was executed directly.
