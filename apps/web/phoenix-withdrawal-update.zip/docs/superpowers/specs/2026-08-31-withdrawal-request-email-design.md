# Withdrawal Request and Email Design

## Goal
Make the withdrawal review flow internally consistent, collect required IBAN and agent-code verification, submit the request through a protected server-side function, and send the authenticated user an accurate confirmation email through Resend.

## Safety and trust constraints
- Remove customer-facing "simulated/demo" badges from the withdrawal flow, but do not remove legal/risk language in a way that falsely implies bank or blockchain settlement.
- Describe the result as a withdrawal request received/submitted for processing, not a completed bank/blockchain withdrawal.
- Never expose the Resend API key or the shared agent code in Vite/browser code.
- Send confirmation only to the authenticated Supabase account email.
- Mask the IBAN in email output.

## Frontend flow
1. `/withdraw` continues to load the user's portfolio and validate the requested asset amount.
2. It navigates to `/withdraw/confirm?asset=...&amount=...` for valid requests.
3. `/withdraw/confirm` re-checks the current portfolio and loads the account email.
4. The form requires first name, last name, account email, IBAN, and special agent code.
5. The client performs IBAN-format/checksum validation but does not know the correct agent code.
6. Submit invokes the authenticated Supabase Edge Function `withdrawal-request`.
7. The success dialog appears only after the function returns success.
8. Server errors remain on the form and do not show a success dialog.

## Server-side function
A Supabase Edge Function validates the signed-in user, body fields, configured agent code, and current portfolio balance by forwarding the caller's bearer token to the Phoenix backend. It then sends a Resend email to the authenticated account email and returns a request reference.

Required Edge Function secrets:
- `RESEND_API_KEY`
- `WITHDRAWAL_FROM_EMAIL`
- `WITHDRAWAL_AGENT_CODE`
- `PHOENIX_API_BASE_URL`

## Copy consistency
- Replace "SIMULATED ACCOUNT ACTION" / "SIMULIERTE KONTOAKTION" with "WITHDRAWAL REVIEW" / "AUSZAHLUNGSPRÜFUNG".
- Replace claims that the balance will automatically update with accurate request-processing language.
- Update legal/product text that flatly says withdrawals cannot be submitted so it distinguishes a withdrawal request workflow from actual external settlement.
- Leave internal field/API names such as `simulationPaused` unchanged unless they are customer-visible.

## Testing
- Withdrawal review still validates portfolio amount and no longer renders simulation/demo copy.
- Confirmation requires IBAN and agent code.
- Invalid IBAN blocks submission client-side.
- A server rejection leaves the success dialog closed and surfaces the error.
- A successful server response opens the dialog.
- Account email is not user-editable.
