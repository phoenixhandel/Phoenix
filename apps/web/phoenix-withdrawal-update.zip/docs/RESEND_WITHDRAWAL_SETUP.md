# Resend + Supabase withdrawal email setup

The frontend invokes the authenticated Supabase Edge Function named `withdrawal-request`. The function keeps the Resend API key and shared agent code server-side, re-checks the user's current Phoenix portfolio, and sends the confirmation only to the email address in the authenticated Supabase JWT.

## 1. Verify a sending domain in Resend

1. In Resend, open **Domains** and add a domain you control. A subdomain such as `updates.example.com` is a clean option for transactional mail.
2. Add the DNS records Resend gives you at your DNS provider.
3. Wait until Resend marks the domain as verified.
4. Choose a sender address on that verified domain, for example:

```text
Phoenix <withdrawals@updates.example.com>
```

Do not use an arbitrary unverified From address in production.

## 2. Create or reuse a Resend API key

Create a Resend API key with sending access. Keep the value server-side only. It normally begins with `re_`.

Do **not** put this value in `.env` variables prefixed with `VITE_`; Vite variables are shipped to the browser.

## 3. Configure the Edge Function secrets

Copy the example file locally:

```bash
cp supabase/functions/.env.example supabase/functions/.env
```

Fill it with real values:

```dotenv
RESEND_API_KEY=re_xxxxxxxxx
WITHDRAWAL_FROM_EMAIL="Phoenix <withdrawals@updates.example.com>"
WITHDRAWAL_AGENT_CODE=YOUR_SHARED_AGENT_CODE
PHOENIX_API_BASE_URL=https://your-phoenix-api.example.com
```

`PHOENIX_API_BASE_URL` must be reachable from Supabase's hosted Edge Function. A localhost-only backend will not work after deployment.

The shared code is intentionally stored as `WITHDRAWAL_AGENT_CODE`; it is not compiled into React.

## 4. Link the local project to Supabase

If the project is not linked yet:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
```

Your project ref is the short identifier from the Supabase project URL/dashboard.

## 5. Upload the secrets to Supabase

From the project root:

```bash
supabase secrets set --env-file supabase/functions/.env
```

You can confirm the secret names are present with:

```bash
supabase secrets list
```

Do not paste the real values into source control.

## 6. Deploy the withdrawal function

```bash
supabase functions deploy withdrawal-request
```

The included `supabase/config.toml` keeps JWT verification enabled. Do not deploy this function with `--no-verify-jwt`; it is intended to be called only by signed-in users.

## 7. Frontend requirements

The existing app already initializes Supabase from:

```dotenv
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_BROWSER_SAFE_ANON_KEY
```

No Resend key or agent code belongs in the frontend environment.

After deployment, `supabase.functions.invoke("withdrawal-request", ...)` uses the signed-in user's Supabase session and sends the JWT automatically.

## 8. End-to-end smoke test

1. Sign in to Phoenix with a verified account.
2. Make sure the Phoenix backend returns a positive balance from `/api/me/portfolio`.
3. Open `/withdraw`, select an asset, and choose an amount no larger than the available balance.
4. Continue to the confirmation page.
5. Enter a valid IBAN.
6. Enter the configured agent code.
7. Submit the withdrawal request.
8. The success dialog should appear only after the Edge Function returns success.
9. Check the user's inbox and the Resend **Emails** dashboard. The email should show the amount, masked IBAN, and request reference.

## 9. Common failures

### `401` / Edge Function not invoked

The user session is missing or expired. Confirm the browser has an active Supabase session and that the function was not deployed with incompatible auth configuration.

### `INVALID_AGENT_CODE`

The entered value does not match the `WITHDRAWAL_AGENT_CODE` secret in Supabase.

To set the requested shared value explicitly:

```bash
supabase secrets set WITHDRAWAL_AGENT_CODE=YOUR_SHARED_AGENT_CODE
```

### `EMAIL_MISMATCH`

The email shown by the Phoenix account settings does not match the email in the authenticated Supabase JWT. The function deliberately refuses to send to arbitrary addresses.

### `PORTFOLIO_UNAVAILABLE`

`PHOENIX_API_BASE_URL` is wrong, unavailable, or inaccessible from the Supabase Edge runtime. The function forwards the user's bearer token to:

```text
GET {PHOENIX_API_BASE_URL}/api/me/portfolio
```

That endpoint must accept the same Supabase access token used by the frontend.

### `INSUFFICIENT_BALANCE`

The function performs its own balance check immediately before sending the confirmation. This protects against stale or tampered query-string values.

### `EMAIL_DELIVERY_FAILED`

Check:

- `RESEND_API_KEY`
- `WITHDRAWAL_FROM_EMAIL`
- Resend domain verification
- Resend delivery logs
- Supabase **Functions → withdrawal-request → Logs**

## 10. Important behavior

This implementation sends a confirmation that the withdrawal **request was received for processing**. It does not itself perform a bank transfer, broadcast a blockchain transaction, or debit the Phoenix portfolio because the supplied archive did not include a backend withdrawal/ledger endpoint.

If the Phoenix backend later exposes a real withdrawal-record endpoint, add that server-side step before the Resend call so the email is tied to a persisted request rather than email delivery alone.
